
public class TestaArray {

	public static void main(String[] args) {
		
		ArrayDeInteiros a = new ArrayDeInteiros(10);
		
		a.preencherArray();
		a.exibeArray();
		a.exibeInvertido();

	}

}
