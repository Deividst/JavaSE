package Lista05;


public class TesteRepeticoes{
    public static void main(String [] args){
        
        Repeticoes r = new Repeticoes();
        
        r.listaInteirosDe1aN(10);
        r.listaParesPositivosMenoresQue(20);
        r.calculaMediaIdades(5);
        r.achaMaior(3);
        
        
        
    }
}